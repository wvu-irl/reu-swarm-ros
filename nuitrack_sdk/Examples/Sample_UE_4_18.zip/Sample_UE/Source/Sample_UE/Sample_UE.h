// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "Engine.h"

#include <iostream>
#include <vector>

using namespace std;

#if WITH_NUITRACK
#define ANDROID 1 // for nuitrack

#include "nuitrack/Nuitrack.h"
#include "nuitrack/modules/SkeletonTracker.h"
#include "nuitrack/types/Skeleton.h"
#include "nuitrack/types/SkeletonData.h"

using namespace tdv::nuitrack;

#endif
