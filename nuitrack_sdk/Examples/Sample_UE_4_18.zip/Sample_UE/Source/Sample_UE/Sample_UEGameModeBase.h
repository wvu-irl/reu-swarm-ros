// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "Sample_UE.h"
#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "Sample_UEGameModeBase.generated.h"

/**
 * 
 */
UCLASS()
class SAMPLE_UE_API ASample_UEGameModeBase : public AGameModeBase
{
	GENERATED_BODY()
	
	UWorld* World;

	ASample_UEGameModeBase();

	void Tick(float dt) override;
	void BeginPlay() override;
	void BeginDestroy() override;

#if WITH_NUITRACK

	SkeletonTracker::Ptr skeletonTracker;

	void OnSkeletonUpdate(SkeletonData::Ptr userSkeletons);
	void DrawSkeleton(int skeleton_index, vector<Joint> joints);
	void DrawBone(Joint j1, Joint j2);

	static FVector RealToPosition(Vector3 real);

#endif
	
};
