#include <iostream>
#include "Game.h"

int main()
{
    Game game;
    game.Run();
    return 0;
}

//Aleks Hatfield
//May 29, 2019
//WVU Robotics REU
